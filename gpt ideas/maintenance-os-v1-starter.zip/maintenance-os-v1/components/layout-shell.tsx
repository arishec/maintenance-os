import Link from 'next/link';
import { ClipboardList, HardHat, House, LayoutDashboard } from 'lucide-react';

const nav = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/properties', label: 'Properties', icon: House },
  { href: '/issues', label: 'Issues', icon: ClipboardList },
  { href: '/contractors', label: 'Contractors', icon: HardHat },
];

export function LayoutShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="mx-auto grid max-w-7xl grid-cols-1 gap-6 px-4 py-6 lg:grid-cols-[220px_minmax(0,1fr)] lg:px-8">
        <aside className="rounded-2xl border border-border bg-white p-4 shadow-sm">
          <div className="mb-6 px-2">
            <div className="text-lg font-semibold">Maintenance OS</div>
            <div className="text-sm text-muted-foreground">Homeowner + landlord workflow</div>
          </div>
          <nav className="space-y-1">
            {nav.map((item) => {
              const Icon = item.icon;
              return (
                <Link key={item.href} href={item.href} className="flex items-center gap-3 rounded-xl px-3 py-2 text-sm hover:bg-muted">
                  <Icon className="h-4 w-4" />
                  {item.label}
                </Link>
              );
            })}
          </nav>
        </aside>
        <main>{children}</main>
      </div>
    </div>
  );
}
