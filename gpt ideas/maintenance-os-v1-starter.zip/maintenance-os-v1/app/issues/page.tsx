import { LayoutShell } from '@/components/layout-shell';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const issues = [
  {
    title: 'Kitchen sink leak',
    property: 'Home',
    category: 'plumbing',
    urgency: 'high',
    status: 'awaiting_quotes',
  },
  {
    title: 'Roof drip near attic',
    property: 'Rental #1',
    category: 'roofing',
    urgency: 'medium',
    status: 'classified',
  },
];

export default function IssuesPage() {
  return (
    <LayoutShell>
      <Card>
        <CardHeader>
          <CardTitle>Issues</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {issues.map((issue) => (
              <div key={issue.title} className="grid gap-3 rounded-xl border border-border p-4 md:grid-cols-[minmax(0,1fr)_120px_120px_160px] md:items-center">
                <div>
                  <div className="font-medium">{issue.title}</div>
                  <div className="text-sm text-muted-foreground">{issue.property}</div>
                </div>
                <Badge>{issue.category}</Badge>
                <Badge>{issue.urgency}</Badge>
                <Badge>{issue.status}</Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </LayoutShell>
  );
}
