import { LayoutShell } from '@/components/layout-shell';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const properties = [
  { nickname: 'Home', address: '123 Main St, Philadelphia, PA', openIssues: 1 },
  { nickname: 'Rental #1', address: '88 Oak Ave, Bala Cynwyd, PA', openIssues: 2 },
  { nickname: 'Rental #2', address: '17 Cedar Ln, Wynnewood, PA', openIssues: 1 },
];

export default function PropertiesPage() {
  return (
    <LayoutShell>
      <Card>
        <CardHeader>
          <CardTitle>Properties</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {properties.map((property) => (
              <div key={property.nickname} className="grid gap-2 rounded-xl border border-border p-4 md:grid-cols-[220px_minmax(0,1fr)_120px]">
                <div className="font-medium">{property.nickname}</div>
                <div className="text-sm text-muted-foreground">{property.address}</div>
                <div className="text-sm">{property.openIssues} open</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </LayoutShell>
  );
}
