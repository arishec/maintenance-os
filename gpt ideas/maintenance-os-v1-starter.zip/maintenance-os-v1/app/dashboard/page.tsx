import { LayoutShell } from '@/components/layout-shell';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { IssueSummaryCard } from '@/components/issue-summary-card';

const stats = [
  { label: 'Open issues', value: '4' },
  { label: 'Awaiting quotes', value: '2' },
  { label: 'Active jobs', value: '1' },
  { label: 'Properties', value: '3' },
];

export default function DashboardPage() {
  return (
    <LayoutShell>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-semibold">Dashboard</h1>
          <p className="mt-1 text-sm text-muted-foreground">A calm, property-first operating view for homeowners and landlords.</p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {stats.map((stat) => (
            <Card key={stat.label}>
              <CardHeader>
                <CardTitle className="text-sm text-muted-foreground">{stat.label}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-semibold">{stat.value}</div>
              </CardContent>
            </Card>
          ))}
        </div>
        <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_320px]">
          <div className="space-y-4">
            <IssueSummaryCard
              title="Kitchen sink leak"
              property="Home"
              status="awaiting_quotes"
              urgency="high"
              category="plumbing"
              description="Leak under cabinet reported this morning. Waiting on contractor replies."
            />
            <IssueSummaryCard
              title="Bathroom exhaust fan not working"
              property="Rental #2"
              status="classified"
              urgency="medium"
              category="electrical"
              description="Tenant reported fan stopped turning on. Needs electrician or handyman."
            />
          </div>
          <Card>
            <CardHeader>
              <CardTitle>Build status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm text-muted-foreground">
              <p>This starter includes the locked stack, Prisma schema, API routes, Claude services, and the first UI surfaces.</p>
              <p>Next steps are wiring the UI to live data and completing Twilio, Resend, and Supabase flows in your environment.</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </LayoutShell>
  );
}
