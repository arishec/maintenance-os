import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { requireDbUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { classifyIssue } from '@/lib/ai/classify-issue';

const issueSchema = z.object({
  propertyId: z.string().uuid(),
  description: z.string().min(5),
  locationInProperty: z.string().optional(),
  signals: z.array(z.string()).optional(),
});

export async function GET() {
  try {
    const user = await requireDbUser();
    const issues = await prisma.issue.findMany({
      where: { property: { ownerUserId: user.id } },
      include: { property: true, usageMetrics: true },
      orderBy: { createdAt: 'desc' },
    });
    return NextResponse.json({ issues });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    return NextResponse.json({ error: message }, { status: 401 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireDbUser();
    const body = issueSchema.parse(await request.json());

    const property = await prisma.property.findFirst({
      where: { id: body.propertyId, ownerUserId: user.id },
    });

    if (!property) {
      return NextResponse.json({ error: 'Property not found.' }, { status: 404 });
    }

    const initialIssue = await prisma.issue.create({
      data: {
        propertyId: property.id,
        reportedByUserId: user.id,
        sourceType: 'owner_app',
        description: body.description,
        locationInProperty: body.locationInProperty,
        status: 'new',
      },
    });

    const classification = await classifyIssue({
      description: body.description,
      locationInProperty: body.locationInProperty,
      signals: body.signals,
    });

    const issue = await prisma.issue.update({
      where: { id: initialIssue.id },
      data: {
        title: classification.title,
        category: classification.category,
        urgency: classification.urgency,
        reasoningSummary: classification.reasoningSummary,
        suggestedTimeframe: classification.suggestedTimeframe,
        recommendedTrade: classification.recommendedTrade,
        aiConfidence: classification.confidenceScore,
        status: 'classified',
        usageMetrics: {
          create: {
            aiRequestCount: 1,
          },
        },
      },
    });

    return NextResponse.json({ issue }, { status: 201 });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
