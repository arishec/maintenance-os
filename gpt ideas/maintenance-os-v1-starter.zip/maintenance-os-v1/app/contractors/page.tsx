import { LayoutShell } from '@/components/layout-shell';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const contractors = [
  { name: 'Mike’s Plumbing', trade: 'plumbing', contact: '(555) 111-1111' },
  { name: 'Elite Roofing', trade: 'roofing', contact: '(555) 333-3333' },
  { name: 'QuickFix Handyman', trade: 'handyman', contact: 'help@quickfix.example' },
];

export default function ContractorsPage() {
  return (
    <LayoutShell>
      <Card>
        <CardHeader>
          <CardTitle>Contractors</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {contractors.map((contractor) => (
              <div key={contractor.name} className="grid gap-2 rounded-xl border border-border p-4 md:grid-cols-[minmax(0,1fr)_160px_220px]">
                <div className="font-medium">{contractor.name}</div>
                <div className="text-sm text-muted-foreground">{contractor.trade}</div>
                <div className="text-sm">{contractor.contact}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </LayoutShell>
  );
}
